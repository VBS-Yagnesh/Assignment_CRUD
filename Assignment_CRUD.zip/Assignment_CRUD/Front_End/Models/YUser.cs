﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Front_End.Models
{
    public class YUser
    {
        public int Id { set; get; }
        public string Name { get; set; }
        public string City { get; set; }
    }
}
