﻿using Front_End.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Front_End.Controllers
{
    public class YagneshAPI
    {
        public HttpClient ApiClient()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:44395/");
            return client;
        }
    }

        public class HomeController : Controller
    {
        YagneshAPI _API = new YagneshAPI();

        public async Task<IActionResult> Index()
        {
            List<YUser> yUser = new List<YUser>();
            HttpClient client =  _API.ApiClient();
            HttpResponseMessage response = await client.GetAsync("api/YUser");
            if (response.IsSuccessStatusCode)
            {
                var results = response.Content.ReadAsStringAsync().Result;
               yUser = JsonConvert.DeserializeObject<List<YUser>>(results); // Converts JSON into List format in YUser class
            }
            return View(yUser);

        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public async Task<IActionResult> Details(int Id)
        {
            var det = new YUser();
            HttpClient client = _API.ApiClient();
            HttpResponseMessage response = await client.GetAsync($"api/YUser/{Id}");
            if (response.IsSuccessStatusCode)
            {
                var results = response.Content.ReadAsStringAsync().Result;
                det = JsonConvert.DeserializeObject<YUser>(results);

            }
            return View(det);
        }

        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]

        public IActionResult Create(YUser User)
        {
            HttpClient client = _API.ApiClient();

            //Http Post

            var postTask = client.PostAsJsonAsync<YUser>("api/YUser", User);
            postTask.Wait();

            var result = postTask.Result;
            if (result.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return View();
        }
        public async Task<IActionResult> Delete(int Id)
        {
            var del = new YUser();
            HttpClient client = _API.ApiClient();
            HttpResponseMessage response = await client.DeleteAsync($"api/YUser/{Id}");
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int Id)
        {
            YUser ed = null; ;
            HttpClient client = _API.ApiClient(); // API connection method /*https://localhost:44395*/
            var responseTask = client.GetAsync($"api/YUser/{Id}"); // Getting Address of YUser Controller
            responseTask.Wait();
            var result = responseTask.Result;
            if (result.IsSuccessStatusCode)
            {
                var readTask = result.Content.ReadAsAsync<YUser>();
                readTask.Wait();
                ed = readTask.Result;
            }
            return View(ed);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(YUser User)
        {
            HttpClient client = _API.ApiClient();
            var ed= client.PutAsJsonAsync<YUser>($"api/YUser/{User.Id}", User);
            ed.Wait();

            var result = ed.Result;
            if (result.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return View();
        }



    }
}
