﻿using Assignment_CRUD.DataContext;
using Assignment_CRUD.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment_CRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class YUserController : ControllerBase
    {
        private ApplicationDbContext _context;
        public YUserController(ApplicationDbContext context)
        {
            _context = context;
        }

        //Get all the User list from the table of yUsers from the database.

        [HttpGet]
        public List<YUser> Get()
        {
            return _context.yUsers.ToList();
        }


        [HttpGet("{Id}")]
        public YUser GetUser(int Id)
        {
            var yyUser = _context.yUsers.Where(a => a.Id == Id).FirstOrDefault();
            return yyUser;
        }

        [HttpPost]
        public IActionResult PostUser([FromBody] YUser User)
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid Model");

            _context.yUsers.Add(User);
            _context.SaveChanges();

            return Ok();
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> EditUser([FromBody] YUser User, int Id)
        {
            var ed = await _context.yUsers.FindAsync(Id);
            if (ed != null)
            {
                ed.Name = User.Name;
                ed.City = User.City;
               // _context.yUsers.Update(User);
                _context.SaveChanges();
                return Ok();
            }
            return NoContent();
        }

        [HttpDelete("{Id}")]
        public IActionResult DeleteUser(int Id)
        {
            var del = _context.yUsers.Where(a => a.Id == Id).FirstOrDefault();
            if (del != null)
            {
                _context.yUsers.Remove(del);
                _context.SaveChanges();
                return Ok();
            }
            return NoContent();
        }

    }
}
