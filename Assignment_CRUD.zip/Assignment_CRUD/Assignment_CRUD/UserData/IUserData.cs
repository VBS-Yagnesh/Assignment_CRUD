﻿using Assignment_CRUD.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment_CRUD.UserData
{
    interface IUserData
    {
        List<YUser> GetUser();
        YUser GetUser(int Id);
        YUser AddUser(YUser user);
        YUser EditUser(YUser user);
        YUser DeleteUser(YUser user);

    }
}
